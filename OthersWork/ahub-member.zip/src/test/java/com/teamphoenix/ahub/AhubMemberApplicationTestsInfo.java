package com.teamphoenix.ahub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AhubMemberApplicationTestsInfo {

    @Test
    void contextLoads() {
    }
}

