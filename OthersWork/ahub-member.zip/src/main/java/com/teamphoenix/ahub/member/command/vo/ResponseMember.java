package com.teamphoenix.ahub.member.command.vo;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class ResponseMember {
    private String memberId;
    private String message;
}
